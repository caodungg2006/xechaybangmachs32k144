board/pin_mux.o: ../board/pin_mux.c ../board/pin_mux.h \
 ../SDK/platform/drivers/inc/pins_driver.h \
 D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/device_registers.h \
 D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/common/s32_core_cm4.h \
 D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/S32K144/include/S32K144.h \
 D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/S32K144/include/S32K144_features.h \
 D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/devassert.h \
 D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/status.h

../board/pin_mux.h:

../SDK/platform/drivers/inc/pins_driver.h:

D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/device_registers.h:

D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/common/s32_core_cm4.h:

D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/S32K144/include/S32K144.h:

D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/S32K144/include/S32K144_features.h:

D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/devassert.h:

D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/status.h:
