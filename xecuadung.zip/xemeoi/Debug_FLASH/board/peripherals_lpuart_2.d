board/peripherals_lpuart_2.o: ../board/peripherals_lpuart_2.c \
 ../board/peripherals_lpuart_2.h \
 ../SDK/platform/drivers/inc/lpuart_driver.h \
 D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/device_registers.h \
 D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/common/s32_core_cm4.h \
 D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/S32K144/include/S32K144.h \
 D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/S32K144/include/S32K144_features.h \
 D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/devassert.h \
 D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/status.h \
 ../SDK/platform/drivers/inc/interrupt_manager.h ../SDK/rtos/osif/osif.h \
 ../SDK/platform/drivers/inc/edma_driver.h \
 D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/callbacks.h

../board/peripherals_lpuart_2.h:

../SDK/platform/drivers/inc/lpuart_driver.h:

D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/device_registers.h:

D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/common/s32_core_cm4.h:

D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/S32K144/include/S32K144.h:

D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/S32K144/include/S32K144_features.h:

D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/devassert.h:

D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/status.h:

../SDK/platform/drivers/inc/interrupt_manager.h:

../SDK/rtos/osif/osif.h:

../SDK/platform/drivers/inc/edma_driver.h:

D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/callbacks.h:
