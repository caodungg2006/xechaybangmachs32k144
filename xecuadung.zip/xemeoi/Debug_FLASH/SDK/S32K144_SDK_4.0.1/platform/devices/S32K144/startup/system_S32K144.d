SDK/S32K144_SDK_4.0.1/platform/devices/S32K144/startup/system_S32K144.o: \
 ../SDK/S32K144_SDK_4.0.1/platform/devices/S32K144/startup/system_S32K144.c \
 D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/device_registers.h \
 D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/common/s32_core_cm4.h \
 D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/S32K144/include/S32K144.h \
 D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/S32K144/include/S32K144_features.h \
 D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/devassert.h \
 D:/esb/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/devices/S32K144/startup/system_S32K144.h

D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/device_registers.h:

D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/common/s32_core_cm4.h:

D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/S32K144/include/S32K144.h:

D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/S32K144/include/S32K144_features.h:

D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/devassert.h:

D:/esb/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/devices/S32K144/startup/system_S32K144.h:
