SDK/platform/drivers/src/ftm/ftm_hw_access.o: \
 ../SDK/platform/drivers/src/ftm/ftm_hw_access.c \
 ../SDK/platform/drivers/src/ftm/ftm_hw_access.h \
 D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/status.h \
 D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/device_registers.h \
 D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/common/s32_core_cm4.h \
 D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/S32K144/include/S32K144.h \
 D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/S32K144/include/S32K144_features.h \
 D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/devassert.h \
 ../SDK/platform/drivers/inc/interrupt_manager.h \
 D:/esb/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/drivers/inc/clock_manager.h \
 D:/esb/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/drivers/inc/clock.h \
 d:\esb\s32ds\software\s32sdk_s32k1xx_rtm_4.0.1\platform\drivers\src\clock\s32k1xx\clock_s32k1xx.h \
 ../SDK/platform/drivers/inc/ftm_common.h \
 D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/callbacks.h

../SDK/platform/drivers/src/ftm/ftm_hw_access.h:

D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/status.h:

D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/device_registers.h:

D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/common/s32_core_cm4.h:

D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/S32K144/include/S32K144.h:

D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/S32K144/include/S32K144_features.h:

D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/devassert.h:

../SDK/platform/drivers/inc/interrupt_manager.h:

D:/esb/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/drivers/inc/clock_manager.h:

D:/esb/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/drivers/inc/clock.h:

d:\esb\s32ds\software\s32sdk_s32k1xx_rtm_4.0.1\platform\drivers\src\clock\s32k1xx\clock_s32k1xx.h:

../SDK/platform/drivers/inc/ftm_common.h:

D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/callbacks.h:
