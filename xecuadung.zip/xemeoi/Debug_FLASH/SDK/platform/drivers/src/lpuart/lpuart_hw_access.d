SDK/platform/drivers/src/lpuart/lpuart_hw_access.o: \
 ../SDK/platform/drivers/src/lpuart/lpuart_hw_access.c \
 ../SDK/platform/drivers/src/lpuart/lpuart_hw_access.h \
 ../SDK/platform/drivers/inc/lpuart_driver.h \
 D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/device_registers.h \
 D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/common/s32_core_cm4.h \
 D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/S32K144/include/S32K144.h \
 D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/S32K144/include/S32K144_features.h \
 D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/devassert.h \
 D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/status.h \
 ../SDK/platform/drivers/inc/interrupt_manager.h ../SDK/rtos/osif/osif.h \
 ../SDK/platform/drivers/inc/edma_driver.h \
 D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/callbacks.h

../SDK/platform/drivers/src/lpuart/lpuart_hw_access.h:

../SDK/platform/drivers/inc/lpuart_driver.h:

D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/device_registers.h:

D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/common/s32_core_cm4.h:

D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/S32K144/include/S32K144.h:

D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/S32K144/include/S32K144_features.h:

D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/devassert.h:

D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/status.h:

../SDK/platform/drivers/inc/interrupt_manager.h:

../SDK/rtos/osif/osif.h:

../SDK/platform/drivers/inc/edma_driver.h:

D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/callbacks.h:
