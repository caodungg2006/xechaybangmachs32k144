SDK/platform/drivers/src/lpuart/lpuart_irq.o: \
 ../SDK/platform/drivers/src/lpuart/lpuart_irq.c \
 ../SDK/platform/drivers/src/lpuart/lpuart_irq.h \
 D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/device_registers.h \
 D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/common/s32_core_cm4.h \
 D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/S32K144/include/S32K144.h \
 D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/S32K144/include/S32K144_features.h \
 D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/devassert.h \
 ../SDK/platform/drivers/inc/interrupt_manager.h

../SDK/platform/drivers/src/lpuart/lpuart_irq.h:

D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/device_registers.h:

D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/common/s32_core_cm4.h:

D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/S32K144/include/S32K144.h:

D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/S32K144/include/S32K144_features.h:

D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/devassert.h:

../SDK/platform/drivers/inc/interrupt_manager.h:
