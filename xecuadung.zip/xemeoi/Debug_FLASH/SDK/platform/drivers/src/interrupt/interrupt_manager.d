SDK/platform/drivers/src/interrupt/interrupt_manager.o: \
 ../SDK/platform/drivers/src/interrupt/interrupt_manager.c \
 ../SDK/platform/drivers/inc/interrupt_manager.h \
 D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/device_registers.h \
 D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/common/s32_core_cm4.h \
 D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/S32K144/include/S32K144.h \
 D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/S32K144/include/S32K144_features.h \
 D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/devassert.h \
 D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/startup.h \
 D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/device_registers.h

../SDK/platform/drivers/inc/interrupt_manager.h:

D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/device_registers.h:

D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/common/s32_core_cm4.h:

D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/S32K144/include/S32K144.h:

D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/S32K144/include/S32K144_features.h:

D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/devassert.h:

D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/startup.h:

D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/device_registers.h:
