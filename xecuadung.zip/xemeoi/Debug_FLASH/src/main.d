src/main.o: ../src/main.c D:/esb/xemeoi/board/sdk_project_config.h \
 D:/esb/xemeoi/board/clock_config.h ../SDK/platform/drivers/inc/clock.h \
 D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/device_registers.h \
 D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/common/s32_core_cm4.h \
 D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/S32K144/include/S32K144.h \
 D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/S32K144/include/S32K144_features.h \
 D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/devassert.h \
 D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/status.h \
 ../SDK/platform/drivers/inc/../src/clock/S32K1xx/clock_S32K1xx.h \
 D:/esb/xemeoi/board/pin_mux.h ../SDK/platform/drivers/inc/pins_driver.h \
 D:/esb/xemeoi/board/peripherals_flexTimer_pwm2.h \
 ../SDK/platform/drivers/inc/ftm_pwm_driver.h \
 ../SDK/platform/drivers/inc/ftm_common.h \
 D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/callbacks.h \
 D:/esb/xemeoi/board/peripherals_lpuart_2.h \
 ../SDK/platform/drivers/inc/lpuart_driver.h \
 ../SDK/platform/drivers/inc/interrupt_manager.h ../SDK/rtos/osif/osif.h \
 ../SDK/platform/drivers/inc/edma_driver.h \
 D:/esb/xemeoi/board/peripherals_lpuart_1_InitConfig0.h

D:/esb/xemeoi/board/sdk_project_config.h:

D:/esb/xemeoi/board/clock_config.h:

../SDK/platform/drivers/inc/clock.h:

D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/device_registers.h:

D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/common/s32_core_cm4.h:

D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/S32K144/include/S32K144.h:

D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/S32K144/include/S32K144_features.h:

D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/devassert.h:

D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/status.h:

../SDK/platform/drivers/inc/../src/clock/S32K1xx/clock_S32K1xx.h:

D:/esb/xemeoi/board/pin_mux.h:

../SDK/platform/drivers/inc/pins_driver.h:

D:/esb/xemeoi/board/peripherals_flexTimer_pwm2.h:

../SDK/platform/drivers/inc/ftm_pwm_driver.h:

../SDK/platform/drivers/inc/ftm_common.h:

D:/esb/xemeoi/SDK/S32K144_SDK_4.0.1/platform/devices/callbacks.h:

D:/esb/xemeoi/board/peripherals_lpuart_2.h:

../SDK/platform/drivers/inc/lpuart_driver.h:

../SDK/platform/drivers/inc/interrupt_manager.h:

../SDK/rtos/osif/osif.h:

../SDK/platform/drivers/inc/edma_driver.h:

D:/esb/xemeoi/board/peripherals_lpuart_1_InitConfig0.h:
