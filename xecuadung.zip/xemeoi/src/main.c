/*
 * Xe dieu khien Bluetooth + WiFi - S32K144 + HC-05 + ESP8266 + L298N
 *
 * Ten component trong .mex phai KHOP voi code nay:
 *   - Pins     : g_pin_mux_InitConfigArr0 / NUM_OF_CONFIGURED_PINS0
 *   - LPUART   : instance 2U (LPUART2), config lpuart_2_InitConfig0   (9600, 8N1)
 *   - LPUART1 (ESP8266): config lpuart_1_InitConfig0 (9600, 8N1, Interrupt), chi can chan RX
 *   - FTM PWM  : instance 2U (FTM2),    config flexTimer_pwm2_InitConfig
 *                                              pwm    flexTimer_pwm2_PwmConfig
 *                (2 kenh doc lap: channel 0 = PTD10 = ENA, channel 1 = PTD11 = ENB)
 *
 * Lenh tu app Bluetooth Electronics:
 *   F = tien, B = lui, L = re trai, R = re phai
 *   c = tha nut re (ve giua), f = tha ga (dung tien/lui, giu huong lai)
 *   S/s = dung han, X = xoay 360 do
 *   1 / 2 / 3 = chon so (toc do toi da 50% / 80% / 100%)
 *   A = tu chay chu CAO DUNG, K / J = hieu chinh quang duong / goc xoay (xem muc TU DONG)
 */

#include "sdk_project_config.h"
#include <stdint.h>
#include <stdbool.h>

/* ---------- Chan dieu khien chieu quay (L298N) tren PTD ---------- */
#define PIN_IN1   13U   /* PTD13 - Banh trai tien */
#define PIN_IN2   12U   /* PTD12 - Banh trai lui  */
#define PIN_IN3   9U    /* PTD9  - Banh phai tien */
#define PIN_IN4   8U    /* PTD8  - Banh phai lui  */

#define PWM_CH_LEFT    0U   /* FTM2_CH0 -> ENA */
#define PWM_CH_RIGHT   1U   /* FTM2_CH1 -> ENB */

/* ---------- Thong so toc do (duty: 0x0000 .. 0x8000 = 0..100%) ---------- */
#define PWM_MIN_START   0x4800U   /* khoang 56%: nguong de motor quay ngay, tang neu con tre, giam neu bi giat */
#define PWM_MAX_SPEED   0x8000U
#define PWM_ACCEL_STEP  0x0180U   /* len full ~0.37 s = (0x8000-PWM_MIN_START)/STEP x 10ms; giam neu con giat, tang neu thay i */
#define TURN_PERCENT    47U       /* banh phia trong khi re chay % toc do */
/* ---------- Xoay 360 do (xoay tu tu, xong xoay nguoc lai) ---------- */
#define SPIN_MAX_SPEED   0x6000U   /* toc do xoay toi da, 75% (khong dung 100%) */
#define SPIN_ACCEL_STEP  0x0200U   /* tang/giam toc moi 10 ms khi xoay */
#define SPIN_HOLD_MS     500U      /* ms giu toc do xoay toi da; chinh de du/thieu 1 vong */
#define SPIN_PAUSE_MS    250U      /* ms nghi giua luot xoay di va xoay lai */

/* ---------- Cap so (gui ky tu '1' '2' '3' tu app) ---------- */
#define GEAR1_SPEED        0x6110U  /* so 1: 50%  */
#define GEAR2_SPEED        0x7110U   /* so 2: 75% (nguon 10V -> tuong duong ~8V vao L298N) */
#define GEAR3_SPEED        0x8000U   /* so 3: 100% */
#define GEAR_DEFAULT_SPEED GEAR3_SPEED   /* so mac dinh khi cap dien */

/* Neu toc do cua so thap hon PWM_MIN_START thi cho xe "dap ga" PWM_MIN_START trong
   START_BOOST_TICKS x 10 ms dau de banh bat quay duoc, roi ha ve toc do cua so */
#define START_BOOST_TICKS  6U

/* ---------- Trang thai ---------- */
typedef enum { THROTTLE_STOP = 0, THROTTLE_FWD, THROTTLE_BWD } ThrottleState_t;
typedef enum { STEER_CENTER = 0, STEER_LEFT, STEER_RIGHT } SteerState_t;

static ThrottleState_t currentThrottle = THROTTLE_STOP;
static SteerState_t    currentSteer    = STEER_CENTER;
static uint16_t        currentSpeed    = 0U;
static uint16_t        maxSpeed        = GEAR_DEFAULT_SPEED;   /* toc do toi da cua so dang chon */
static uint8_t         boostTicks      = 0U;                   /* dem nhip dap ga luc xuat phat */

static ftm_state_t     ftmStateStruct;
static lpuart_state_t  lpuart_2_State;
static lpuart_state_t  lpuart_1_State;

/* ---------- Nhan UART bang ngat + bo dem vong, dung cho 2 cong ---------- */
#define RX_BUF_SIZE  32U

typedef struct
{
    volatile uint8_t buf[RX_BUF_SIZE];
    volatile uint8_t head;
    volatile uint8_t tail;
    uint8_t          byte;       /* o nho cho ky tu dang nhan */
    uint32_t         instance;   /* so hieu LPUART */
} UartRx_t;

static UartRx_t rxBt   = { {0U}, 0U, 0U, 0U, 2U };   /* HC-05  : LPUART2 (PTD6/PTD7) */
static UartRx_t rxWifi = { {0U}, 0U, 0U, 0U, 1U };   /* ESP8266: LPUART1 (chan RX theo bang J8) */

static LPUART_Type * const lpuartBases[] = LPUART_BASE_PTRS;

static void Uart_RxCallback(void *driverState, uart_event_t event, void *userData)
{
    UartRx_t *rx = (UartRx_t *)userData;
    (void)driverState;

    if ((event == UART_EVENT_RX_FULL) && (rx != NULL))
    {
        uint8_t next = (uint8_t)((rx->head + 1U) % RX_BUF_SIZE);
        if (next != rx->tail)
        {
            rx->buf[rx->head] = rx->byte;
            rx->head = next;
        }
        LPUART_DRV_SetRxBuffer(rx->instance, &rx->byte, 1U);
    }
}

static void Uart_StartRx(UartRx_t *rx)
{
    LPUART_DRV_InstallRxCallback(rx->instance, Uart_RxCallback, rx);
    LPUART_DRV_ReceiveData(rx->instance, &rx->byte, 1U);
}

/* Bat lai nhan neu UART bi loi/ngung do nhieu */
static void Uart_Keepalive(UartRx_t *rx)
{
    uint32_t remain = 0U;
    if (LPUART_DRV_GetReceiveStatus(rx->instance, &remain) != STATUS_BUSY)
    {
        lpuartBases[rx->instance]->STAT |= (LPUART_STAT_OR_MASK | LPUART_STAT_NF_MASK |
                                            LPUART_STAT_FE_MASK | LPUART_STAT_PF_MASK);
        LPUART_DRV_ReceiveData(rx->instance, &rx->byte, 1U);
    }
}

/* ---------- Nhip 10 ms bang SysTick (khong chan vong lap chinh) ---------- */
static uint32_t ticksPer10ms = 480000U;
static uint32_t lastTick     = 0U;

static void Tick_Init(void)
{
    uint32_t coreFreq = 0U;
    (void)CLOCK_SYS_GetFreq(CORE_CLK, &coreFreq);
    if (coreFreq != 0U) { ticksPer10ms = coreFreq / 100U; }

    S32_SysTick->RVR = 0x00FFFFFFU;
    S32_SysTick->CVR = 0U;
    S32_SysTick->CSR = S32_SysTick_CSR_ENABLE_MASK | S32_SysTick_CSR_CLKSOURCE_MASK;
    lastTick = S32_SysTick->CVR;
}

static bool Tick_Elapsed10ms(void)
{
    uint32_t now     = S32_SysTick->CVR;
    uint32_t elapsed = (lastTick - now) & 0x00FFFFFFU;   /* SysTick dem lui */
    if (elapsed >= ticksPer10ms)
    {
        lastTick = now;
        return true;
    }
    return false;
}

/* Cho xe chay ngay voi toc do khoi dong khi vua bam nut (khong cho nhip tang toc) */
static void Car_Kick(void)
{
    uint16_t start = (PWM_MIN_START < maxSpeed) ? PWM_MIN_START : maxSpeed;

    if ((currentSpeed == 0U) && (maxSpeed < PWM_MIN_START))
    {
        boostTicks = START_BOOST_TICKS;      /* so thap: dap ga mot chut cho banh bat quay */
    }
    if (currentSpeed < start) { currentSpeed = start; }
}

/* ---------- PWM ---------- */
static void Car_SetSpeed(uint16_t left, uint16_t right)
{
    FTM_DRV_UpdatePwmChannel(2U, PWM_CH_LEFT,  FTM_PWM_UPDATE_IN_DUTY_CYCLE, left,  0U, true);
    FTM_DRV_UpdatePwmChannel(2U, PWM_CH_RIGHT, FTM_PWM_UPDATE_IN_DUTY_CYCLE, right, 0U, true);
}

/* ---------- Chieu quay: 1 = tien, -1 = lui, 0 = dung ---------- */
static void Car_SetMotorDir(int8_t left, int8_t right)
{
    if (left > 0)       { PINS_DRV_SetPins(PTD, (1UL << PIN_IN1));  PINS_DRV_ClearPins(PTD, (1UL << PIN_IN2)); }
    else if (left < 0)  { PINS_DRV_ClearPins(PTD, (1UL << PIN_IN1)); PINS_DRV_SetPins(PTD, (1UL << PIN_IN2));  }
    else                { PINS_DRV_ClearPins(PTD, (1UL << PIN_IN1) | (1UL << PIN_IN2)); }

    if (right > 0)      { PINS_DRV_SetPins(PTD, (1UL << PIN_IN3));  PINS_DRV_ClearPins(PTD, (1UL << PIN_IN4)); }
    else if (right < 0) { PINS_DRV_ClearPins(PTD, (1UL << PIN_IN3)); PINS_DRV_SetPins(PTD, (1UL << PIN_IN4));  }
    else                { PINS_DRV_ClearPins(PTD, (1UL << PIN_IN3) | (1UL << PIN_IN4)); }
}

/* ---------- Ap dung trang thai hien tai len motor ---------- */
static void Car_ApplyMovement(void)
{
    uint16_t speed = currentSpeed;
    if ((boostTicks > 0U) && (speed < PWM_MIN_START)) { speed = PWM_MIN_START; }

    uint16_t slow = (uint16_t)(((uint32_t)speed * TURN_PERCENT) / 100U);

    if (currentThrottle != THROTTLE_STOP)
    {
        int8_t dir = (currentThrottle == THROTTLE_FWD) ? 1 : -1;
        Car_SetMotorDir(dir, dir);

        if (currentSteer == STEER_LEFT)       { Car_SetSpeed(slow, speed); }
        else if (currentSteer == STEER_RIGHT) { Car_SetSpeed(speed, slow); }
        else                                  { Car_SetSpeed(speed, speed); }
    }
    else if (currentSteer == STEER_LEFT)      /* quay tai cho */
    {
        Car_SetMotorDir(-1, 1);
        Car_SetSpeed(speed, speed);
    }
    else if (currentSteer == STEER_RIGHT)
    {
        Car_SetMotorDir(1, -1);
        Car_SetSpeed(speed, speed);
    }
    else                                      /* dung han */
    {
        currentSpeed = 0U;
        boostTicks   = 0U;
        Car_SetSpeed(0U, 0U);
        Car_SetMotorDir(0, 0);
    }
}

/* ---------- Tang toc em, goi moi 10 ms ---------- */
static void Car_RampUpSpeed_Task(void)
{
    bool isMoving = (currentThrottle != THROTTLE_STOP) || (currentSteer != STEER_CENTER);

    if (isMoving)
    {
        uint16_t start = (PWM_MIN_START < maxSpeed) ? PWM_MIN_START : maxSpeed;

        if (boostTicks > 0U) { boostTicks--; }

        if (currentSpeed < start)
        {
            currentSpeed = start;
        }
        else if (currentSpeed < maxSpeed)
        {
            currentSpeed = (uint16_t)(currentSpeed + PWM_ACCEL_STEP);
            if (currentSpeed > maxSpeed) { currentSpeed = maxSpeed; }
        }
        else if (currentSpeed > maxSpeed)
        {
            currentSpeed = maxSpeed;
        }
        Car_ApplyMovement();
    }
}

/* ---------- Cho n nhip 10 ms (dung SysTick) ---------- */
static void Wait10ms(uint32_t n)
{
    while (n--)
    {
        lastTick = S32_SysTick->CVR;
        while (!Tick_Elapsed10ms()) { }
    }
}

/* ---------- Xoay tai cho 1 luot: tang toc tu tu -> giu -> giam toc tu tu ----------
   dir = 1  : xoay sang phai (banh trai tien, banh phai lui)
   dir = -1 : xoay sang trai (nguoc lai) */
static void Car_SpinOnce(int8_t dir, uint32_t holdMs)
{
    uint16_t spd = PWM_MIN_START;

    Car_SetMotorDir(dir, (int8_t)(-dir));
    Car_SetSpeed(spd, spd);

    /* Tang toc tu tu */
    while (spd < SPIN_MAX_SPEED)
    {
        Wait10ms(1U);
        spd = (uint16_t)(spd + SPIN_ACCEL_STEP);
        if (spd > SPIN_MAX_SPEED) { spd = SPIN_MAX_SPEED; }
        Car_SetSpeed(spd, spd);
    }

    /* Giu toc do xoay */
    Wait10ms(holdMs / 10U);

    /* Giam toc tu tu */
    while (spd > PWM_MIN_START)
    {
        Wait10ms(1U);
        spd = ((uint16_t)(spd - PWM_MIN_START) > SPIN_ACCEL_STEP) ?
              (uint16_t)(spd - SPIN_ACCEL_STEP) : PWM_MIN_START;
        Car_SetSpeed(spd, spd);
    }

    Car_SetSpeed(0U, 0U);
    Car_SetMotorDir(0, 0);
}

/* ---------- Xoay 360 do roi xoay nguoc lai ---------- */
static void Car_Spin360(void)
{
    boostTicks = 0U;

    Car_SpinOnce(1, SPIN_HOLD_MS);          /* xoay di (sang phai) */
    Wait10ms(SPIN_PAUSE_MS / 10U);          /* nghi mot chut */
    Car_SpinOnce(-1, SPIN_HOLD_MS);         /* xoay lai (sang trai) */

    currentThrottle = THROTTLE_STOP;
    currentSteer    = STEER_CENTER;
    currentSpeed    = 0U;
    Car_ApplyMovement();
}

/* ============================================================
   CHE DO TU DONG: xe tu chay theo duong di cua cac chu "CAO DUNG"
   (chay mo vong theo thoi gian, khong co cam bien -> can hieu chinh)
   Lenh:  A = chay chu CAO DUNG
          K = chay thang 1000 mm (de hieu chinh AUTO_MM_PER_SEC)
          J = xoay phai 360 do   (de hieu chinh AUTO_DEG_PER_SEC)
          S = huy ngay khi dang chay
   ============================================================ */
#define AUTO_SPEED         0x6000U   /* duty khi chay thang (75%) */
#define AUTO_TURN_SPEED    0x6000U   /* duty khi xoay tai cho */
#define AUTO_MM_PER_SEC    200U      /* HIEU CHINH: xe di duoc bao nhieu mm moi giay */
#define AUTO_DEG_PER_SEC   180U      /* HIEU CHINH: xe xoay duoc bao nhieu do moi giay */
#define AUTO_SETTLE_MS     120U      /* nghi sau moi buoc cho xe dung han */
#define AUTO_SCALE_PERCENT 100U      /* ti le kich thuoc chu: 100 = chu cao 300 mm, 50 = 150 mm */

typedef struct { int16_t turn; uint16_t fwd; } AutoStep_t;   /* turn: do (+ phai, - trai); fwd: mm */

/* Duong di sinh tu toa do cac chu (xuat phat o goc duoi-trai, huong len tren) */
static const AutoStep_t scriptCaoDung[] =
{
    /* chu C */
    {   40,  312 },
    {  -80,   79 },
    {  -50,  100 },
    {  -50,   78 },
    {  -40,  180 },
    {  -40,   78 },
    {  -50,  100 },
    {  -50,   78 },
    /* chu A */
    {   81,  117 },
    { -103,  317 },
    {  143,  318 },
    {  180,  111 },
    {  -71,  131 },
    /* chu O */
    { -162,  333 },
    {  -17,   99 },
    {  -51,   77 },
    {  -40,  180 },
    {  -39,   78 },
    {  -51,  101 },
    {  -51,   78 },
    {  -39,  180 },
    {  -40,   77 },
    /* chu D */
    {  -50,  450 },
    {  -90,  299 },
    {   90,  120 },
    {   43,  109 },
    {   47,  150 },
    {   47,  110 },
    {   43,  119 },
    /* chu U */
    {  135,  424 },
    {  135,  240 },
    {  -40,   78 },
    {  -50,  100 },
    {  -50,   78 },
    {  -40,  240 },
    /* chu N */
    {  162,  316 },
    { -162,  300 },
    {  146,  361 },
    { -146,  300 },
    /* chu G */
    {  101,  306 },
    { -142,   77 },
    {  -49,  100 },
    {  -50,   78 },
    {  -40,  180 },
    {  -40,   79 },
    {  -50,  100 },
    {  -51,   78 },
    {  -39,   75 },
    {  -90,   90 },
};
#define SCRIPT_CAO_DUNG_LEN  (sizeof(scriptCaoDung) / sizeof(scriptCaoDung[0]))

static bool autoAbort = false;

/* Doc bo dem UART: thay lenh S/s thi huy, cac lenh khac bo qua khi dang tu dong */
static void Auto_PollAbort(void)
{
    UartRx_t *ports[2] = { &rxBt, &rxWifi };
    for (uint8_t i = 0U; i < 2U; i++)
    {
        while (ports[i]->tail != ports[i]->head)
        {
            uint8_t c = ports[i]->buf[ports[i]->tail];
            ports[i]->tail = (uint8_t)((ports[i]->tail + 1U) % RX_BUF_SIZE);
            if ((c == 'S') || (c == 's')) { autoAbort = true; }
        }
    }
}

static void Auto_Wait(uint32_t n10ms)
{
    while ((n10ms > 0U) && !autoAbort)
    {
        Wait10ms(1U);
        Auto_PollAbort();
        n10ms--;
    }
}

static void Auto_Stop(void)
{
    Car_SetSpeed(0U, 0U);
    Car_SetMotorDir(0, 0);
}

static void Auto_Forward(uint32_t mm)
{
    if ((mm == 0U) || autoAbort) { return; }
    uint32_t ms = (mm * 1000U) / AUTO_MM_PER_SEC;
    Car_SetMotorDir(1, 1);
    Car_SetSpeed(AUTO_SPEED, AUTO_SPEED);
    Auto_Wait(ms / 10U);
    Auto_Stop();
    Auto_Wait(AUTO_SETTLE_MS / 10U);
}

static void Auto_Turn(int16_t deg)
{
    if ((deg == 0) || autoAbort) { return; }
    uint32_t a  = (deg < 0) ? (uint32_t)(-deg) : (uint32_t)deg;
    uint32_t ms = (a * 1000U) / AUTO_DEG_PER_SEC;
    if (deg > 0) { Car_SetMotorDir(1, -1); }    /* xoay phai */
    else         { Car_SetMotorDir(-1, 1); }    /* xoay trai */
    Car_SetSpeed(AUTO_TURN_SPEED, AUTO_TURN_SPEED);
    Auto_Wait(ms / 10U);
    Auto_Stop();
    Auto_Wait(AUTO_SETTLE_MS / 10U);
}

static void Auto_Finish(void)
{
    Auto_Stop();
    currentThrottle = THROTTLE_STOP;
    currentSteer    = STEER_CENTER;
    currentSpeed    = 0U;
    boostTicks      = 0U;
    Car_ApplyMovement();
}

static void Car_AutoScript(void)
{
    autoAbort = false;
    for (uint32_t i = 0U; (i < SCRIPT_CAO_DUNG_LEN) && !autoAbort; i++)
    {
        Auto_Turn(scriptCaoDung[i].turn);
        Auto_Forward(((uint32_t)scriptCaoDung[i].fwd * AUTO_SCALE_PERCENT) / 100U);
    }
    Auto_Finish();
}

static void Car_AutoCalibForward(void)   /* K: chay thang 1000 mm (khong ap dung ti le) */
{
    autoAbort = false;
    Auto_Forward(1000U);
    Auto_Finish();
}

static void Car_AutoCalibTurn(void)      /* J: xoay phai 360 do */
{
    autoAbort = false;
    Auto_Turn(360);
    Auto_Finish();
}

/* ---------- Chon so ---------- */
static void Car_SetGear(uint16_t speed)
{
    maxSpeed = speed;
    if (currentSpeed > maxSpeed) { currentSpeed = maxSpeed; }   /* ha so: giam toc ngay */
    Car_ApplyMovement();
}

/* ---------- Xu ly lenh ---------- */
static void Process_Bluetooth_Command(uint8_t cmd)
{
    switch (cmd)
    {
        case 'F':
            if (currentThrottle == THROTTLE_BWD) { currentSpeed = 0U; }
            currentThrottle = THROTTLE_FWD;
            Car_Kick();
            Car_ApplyMovement();
            break;

        case 'B':
            if (currentThrottle == THROTTLE_FWD) { currentSpeed = 0U; }
            currentThrottle = THROTTLE_BWD;
            Car_Kick();
            Car_ApplyMovement();
            break;

        case 'L': currentSteer = STEER_LEFT;   Car_Kick(); Car_ApplyMovement(); break;
        case 'R': currentSteer = STEER_RIGHT;  Car_Kick(); Car_ApplyMovement(); break;
        case 'c': currentSteer = STEER_CENTER; Car_ApplyMovement(); break;

        case 'f':                               /* tha ga, giu huong lai */
            currentThrottle = THROTTLE_STOP;
            Car_ApplyMovement();
            break;

        case 's':
        case 'S':                               /* dung han */
            currentThrottle = THROTTLE_STOP;
            currentSteer    = STEER_CENTER;
            Car_ApplyMovement();
            break;

        case '1': Car_SetGear(GEAR1_SPEED); break;   /* so 1: 50%  */
        case '2': Car_SetGear(GEAR2_SPEED); break;   /* so 2: 80%  */
        case '3': Car_SetGear(GEAR3_SPEED); break;   /* so 3: 100% */

        case 'X': Car_Spin360(); break;

        case 'A': Car_AutoScript(); break;          /* tu chay chu CAO DUNG */
        case 'K': Car_AutoCalibForward(); break;    /* hieu chinh: thang 1000 mm */
        case 'J': Car_AutoCalibTurn(); break;       /* hieu chinh: xoay phai 360 do */
        default:  break;
    }
}

/* Lay het ky tu trong bo dem cua mot cong va xu ly lenh */
static void Uart_Process(UartRx_t *rx)
{
    while (rx->tail != rx->head)
    {
        uint8_t c = rx->buf[rx->tail];
        rx->tail = (uint8_t)((rx->tail + 1U) % RX_BUF_SIZE);
        Process_Bluetooth_Command(c);
    }
}

int main(void)
{
    /* 1. Clock + Pins */
    CLOCK_SYS_Init(g_clockManConfigsArr, CLOCK_MANAGER_CONFIG_CNT,
                   g_clockManCallbacksArr, CLOCK_MANAGER_CALLBACK_CNT);
    CLOCK_SYS_UpdateConfiguration(0U, CLOCK_MANAGER_POLICY_AGREEMENT);

    PINS_DRV_Init(NUM_OF_CONFIGURED_PINS0, g_pin_mux_InitConfigArr0);

    /* 2. FTM2 PWM */
    FTM_DRV_Init(2U, &flexTimer_pwm2_InitConfig, &ftmStateStruct);
    FTM_DRV_InitPwm(2U, &flexTimer_pwm2_PwmConfig);

    /* 3. UART HC-05 (LPUART2) va ESP8266 (LPUART1), ca hai o che do ngat */
    LPUART_DRV_Init(2U, &lpuart_2_State, &lpuart_2_InitConfig0);
    Uart_StartRx(&rxBt);

    LPUART_DRV_Init(1U, &lpuart_1_State, &lpuart_1_InitConfig0);
    Uart_StartRx(&rxWifi);

    Car_ApplyMovement();   /* khoi dong o trang thai dung */
    Tick_Init();

    while (1)
    {
        Uart_Process(&rxBt);
        Uart_Process(&rxWifi);

        Uart_Keepalive(&rxBt);
        Uart_Keepalive(&rxWifi);

        if (Tick_Elapsed10ms())
        {
            Car_RampUpSpeed_Task();
        }
    }

    return 0;
}
