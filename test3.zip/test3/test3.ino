/*
 * Xe dieu khien WiFi - ESP8266 (NodeMCU / Wemos D1 mini)
 *
 * ESP8266 tu phat WiFi (Access Point) va chay web server.
 * Dien thoai ket noi WiFi "XeWiFi" -> mo trinh duyet vao http://192.168.4.1
 * Moi nut tren trang web gui 1 ky tu qua UART den S32K144:
 *   F tien | B lui | L trai | R phai | f tha ga | c tha lai | S dung | X xoay 360
 *   1 / 2 / 3 = chon so (toc do toi da 50% / 80% / 100%)
 *   A = tu chay chu CAO DUNG | K = thu chay thang 1 m | J = thu xoay 360 do (de hieu chinh)
 * (cung bo lenh voi ban Bluetooth)
 *
 * Day noi:  ESP8266 D4 (GPIO2, TX cua Serial1) --> chan RX LPUART1 cua S32K144
 *           ESP8266 GND                         --> GND board S32K144
 * Chi can 1 day tin hieu, ESP8266 khong can nhan lai du lieu.
 *
 * Arduino IDE: Boards Manager cai "esp8266 by ESP8266 Community",
 *              chon board "NodeMCU 1.0 (ESP-12E Module)".
 */

#include <ESP8266WiFi.h>
#include <ESP8266WebServer.h>

const char *AP_SSID = "XeWiFi";
const char *AP_PASS = "12345678";          // toi thieu 8 ky tu

const unsigned long HOLD_TIMEOUT_MS = 400; // mat lenh giu qua 400 ms thi tu tha nut

ESP8266WebServer server(80);

bool throttleActive = false;
bool steerActive    = false;
unsigned long lastThrottleMs = 0;
unsigned long lastSteerMs    = 0;

/* ---------------- Trang web dieu khien ---------------- */
const char PAGE[] PROGMEM = R"rawliteral(
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<title>Dieu khien xe</title>
<style>
  html,body{margin:0;height:100%;background:#111;color:#fff;font-family:sans-serif;
            -webkit-user-select:none;user-select:none;touch-action:none;overflow:hidden}
  .wrap{display:flex;height:100%;align-items:center;justify-content:space-between;padding:0 4vw}
  .col{display:flex;flex-direction:column;gap:5vh}
  .mid{display:flex;flex-direction:column;gap:3vh;align-items:center}
  .btn{width:28vw;height:36vh;max-height:180px;border-radius:18px;border:2px solid #555;
       background:#2a2a2a;font-size:6vh;display:flex;align-items:center;justify-content:center;
       touch-action:none}
  .btn.on{background:#1e88e5;border-color:#90caf9}
  .small{width:22vw;height:14vh;font-size:3.6vh}
  .stop{background:#b71c1c;border-color:#ef9a9a}
  .stop.on{background:#e53935}
  .gears{display:flex;gap:1.2vw}
  .gbtn{width:7vw;height:11vh;font-size:4vh;border-radius:14px}
  .gbtn.sel{background:#2e7d32;border-color:#a5d6a7}
  .auto{background:#6a1b9a;border-color:#ce93d8}
  .auto.on{background:#ab47bc}
  .calib{display:flex;gap:1.2vw}
  .cbtn{width:10.4vw;height:9vh;font-size:2.4vh;border-radius:12px;text-align:center}
</style>
</head>
<body>
<div class="wrap">
  <div class="col">
    <div class="btn" data-cmd="fwd">&#9650; TIEN (W)</div>
    <div class="btn" data-cmd="bwd">&#9660; LUI (S)</div>
  </div>
  <div class="mid">
    <div class="btn small stop" data-cmd="stop">DUNG (Space)</div>
    <div class="btn small" data-cmd="spin">XOAY (X)</div>
    <div class="gears">
      <div class="btn gbtn" data-cmd="g1">1</div>
      <div class="btn gbtn" data-cmd="g2">2</div>
      <div class="btn gbtn" data-cmd="g3">3</div>
    </div>
    <div class="btn small auto" data-cmd="auto">CHAY CHU (C)</div>
    <div class="calib">
      <div class="btn cbtn" data-cmd="calf">THU THANG (K)</div>
      <div class="btn cbtn" data-cmd="calt">THU XOAY (J)</div>
    </div>
  </div>
  <div class="col">
    <div class="btn" data-cmd="right">PHAI (D) &#9654;</div>
     <div class="btn" data-cmd="left">&#9664; TRAI (A)</div>
  </div>
</div>
<script>
function send(c){ fetch('/c?k=' + c, {cache:'no-store'}).catch(function(){}); }

/* Cau hinh lenh. group: cac phim cung nhom (ga hoac lai) -> phim bam sau cung thang */
var CMD = {
  fwd:   {press:'F', release:'f', repeat:true, group:'t'},
  bwd:   {press:'B', release:'f', repeat:true, group:'t'},
  right:  {press:'L', release:'c', repeat:true, group:'s'},
  left: {press:'R', release:'c', repeat:true, group:'s'},
  stop:  {press:'S', twice:true},
  spin:  {press:'X'},
  auto:  {press:'A'},          /* tu chay chu CAO DUNG (nut Dung S se huy) */
  calf:  {press:'K'},          /* hieu chinh: chay thang 1000 mm */
  calt:  {press:'J'},          /* hieu chinh: xoay phai 360 do */
  g1:    {press:'1', twice:true, gear:true},
  g2:    {press:'2', twice:true, gear:true},
  g3:    {press:'3', twice:true, gear:true}
};

/* Phim ban phim -> lenh (WASD va phim mui ten) */
var KEYS = {
  KeyW:'fwd',  ArrowUp:'fwd',
  KeyS:'bwd',  ArrowDown:'bwd',
  KeyA:'left', ArrowLeft:'left',
  KeyD:'right',ArrowRight:'right',
  Space:'stop',
  KeyX:'spin',
  KeyC:'auto',
  KeyK:'calf',
  KeyJ:'calt',
  Digit1:'g1', Numpad1:'g1',
  Digit2:'g2', Numpad2:'g2',
  Digit3:'g3', Numpad3:'g3'
};

var held = {};                 /* id -> true neu dang giu */
var groups = {t:[], s:[]};     /* thu tu cac phim dang giu trong moi nhom */
var timers = {t:null, s:null}; /* timer lap lai lenh cua phim dang thang trong nhom */

function startRepeat(g, cfg){
  if (timers[g]) clearInterval(timers[g]);
  timers[g] = setInterval(function(){ send(cfg.press); }, 150);
}

function selectGear(name){
  document.querySelectorAll('.gbtn').forEach(function(b){ b.classList.remove('sel'); });
  var el = document.querySelector('[data-cmd="' + name + '"]');
  if (el) el.classList.add('sel');
}

function begin(id, name){
  if (held[id]) return;
  var cfg = CMD[name];
  held[id] = name;
  send(cfg.press);
  if (cfg.twice){ setTimeout(function(){ send(cfg.press); }, 60); }   /* gui 2 lan cho chac */
  if (cfg.gear){ selectGear(name); }
  if (cfg.group){
    groups[cfg.group].push(id);
    startRepeat(cfg.group, cfg);
  }
}

function end(id){
  var name = held[id];
  if (!name) return;
  delete held[id];
  var cfg = CMD[name];
  if (!cfg.group) return;
  var g = cfg.group;
  var list = groups[g];
  list.splice(list.indexOf(id), 1);
  if (list.length > 0){
    /* con phim khac trong nhom dang giu -> tiep tuc lenh cua phim do */
    var next = CMD[held[list[list.length - 1]]];
    send(next.press);
    startRepeat(g, next);
  } else {
    if (timers[g]){ clearInterval(timers[g]); timers[g] = null; }
    send(cfg.release);
    setTimeout(function(){ send(cfg.release); }, 60);
  }
}

function endAll(){ Object.keys(held).forEach(end); }

/* ---- Ban phim ---- */
window.addEventListener('keydown', function(e){
  var name = KEYS[e.code];
  if (!name) return;
  e.preventDefault();
  if (e.repeat) return;
  begin(e.code, name);
  var btn = document.querySelector('[data-cmd="' + name + '"]');
  if (btn) btn.classList.add('on');
});
window.addEventListener('keyup', function(e){
  var name = KEYS[e.code];
  if (!name) return;
  e.preventDefault();
  end(e.code);
  var btn = document.querySelector('[data-cmd="' + name + '"]');
  if (btn) btn.classList.remove('on');
});
window.addEventListener('blur', endAll);   /* roi khoi trang -> tha het nut */

/* ---- Nut cam ung / chuot ---- */
document.querySelectorAll('.btn').forEach(function(el, i){
  var name = el.dataset.cmd;
  var id = 'btn' + i;
  function down(e){
    e.preventDefault();
    el.setPointerCapture(e.pointerId);
    el.classList.add('on');
    begin(id, name);
  }
  function up(e){
    el.classList.remove('on');
    end(id);
  }
  el.addEventListener('pointerdown', down);
  el.addEventListener('pointerup', up);
  el.addEventListener('pointercancel', up);
  el.addEventListener('lostpointercapture', up);
  el.addEventListener('contextmenu', function(e){ e.preventDefault(); });
});
</script>
</body>
</html>
)rawliteral";

/* ---------------- Xu ly lenh ---------------- */
void handleRoot()
{
    server.send_P(200, "text/html", PAGE);
}

void handleCmd()
{
    if (server.hasArg("k") && server.arg("k").length() > 0)
    {
        char c = server.arg("k")[0];
        switch (c)
        {
            case 'F':
            case 'B':
                Serial1.write(c);
                throttleActive = true;
                lastThrottleMs = millis();
                break;
            case 'L':
            case 'R':
                Serial1.write(c);
                steerActive = true;
                lastSteerMs = millis();
                break;
            case 'f':
                Serial1.write(c);
                throttleActive = false;
                break;
            case 'c':
                Serial1.write(c);
                steerActive = false;
                break;
            case 'S':
                Serial1.write('S');
                throttleActive = false;
                steerActive    = false;
                break;
            case '1':
            case '2':
            case '3':
                Serial1.write(c);        // chon so
                break;
            case 'X':
                Serial1.write('X');
                break;
            case 'A':                // tu chay chu CAO DUNG
            case 'K':                // hieu chinh: chay thang
            case 'J':                // hieu chinh: xoay
                Serial1.write(c);
                throttleActive = false;
                steerActive    = false;
                break;
            default:
                break;
        }
    }
    server.send(204, "text/plain", "");
}

void setup()
{
    Serial1.begin(9600);            // TX = GPIO2 (D4), chi gui

    WiFi.mode(WIFI_AP);
    WiFi.softAP(AP_SSID, AP_PASS);  // IP mac dinh 192.168.4.1

    server.on("/", handleRoot);
    server.on("/c", handleCmd);
    server.begin();
}

void loop()
{
    server.handleClient();

    /* An toan: khong nhan duoc lenh giu trong 400 ms (mat song, thoat web, het pin...)
       thi tu tha ga / tha lai de xe khong chay mat kiem soat */
    unsigned long now = millis();
    if (throttleActive && (now - lastThrottleMs > HOLD_TIMEOUT_MS))
    {
        Serial1.write('f');
        throttleActive = false;
    }
    if (steerActive && (now - lastSteerMs > HOLD_TIMEOUT_MS))
    {
        Serial1.write('c');
        steerActive = false;
    }
}
